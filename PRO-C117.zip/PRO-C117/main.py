import os
import cv2

ruta = '/media/joel-botero/EC4E7D574E7D1B90/Byjus/Clases/PRO-C117/C117'

images = []

for archivo in os.listdir(ruta):
    nombre, extension = os.splitext(archivo)
    
    if extension.lower() in ['.jpg', '.jpeg', '.png']:
        file_name = os.path.join(ruta, archivo)
        
        print(file_name)
        
        images.append(file_name)

count = len(images)
frame = cv2.imread(images[0])
height, width, channels = frame.shape

size = (width, height)

print(size)

fourcc = cv2.VideoWriter_fourcc(*'DIVX')
out = cv2.VideoWriter('Video.avi', fourcc, 0.8, size)

for i in range(count):
    frame = cv2.imread(images[i])
    out.write(frame)

out.release()

print("Fin")
